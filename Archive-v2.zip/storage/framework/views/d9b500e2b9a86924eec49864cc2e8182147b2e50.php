<?php $__env->startSection('content'); ?>
    <script type="text/javascript" src="<?php echo e('lib/DataTables/datatables.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo e('js/data-table.js'); ?>"></script>
    <div class="card">
        <div class="card-header">
            Marka Yönetimi
        </div>
        <div class="card-body">
            <a href="/brands/create" class="btn btn-primary"><i class="fas fa-plus"></i> Yeni Ekle</a>
            <hr>
            <table  class="data-table">
                <thead>
                <tr>
                    <th>Logo</th>
                    <th>Marka</th>
                    <th>İşlemler</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img src="<?php echo e(env('AWS_URL')); ?>/<?php echo e($brand->image); ?>" alt="<?php echo e($brand->name); ?>" width="100" class="img-thumbnail">
                        </td>
                        <td><?php echo e($brand->name); ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    İşlemler
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="/brands/<?php echo e($brand->id); ?>/edit"><i class="fas fa-edit"></i> Düzenle</a>
                                    <a class="dropdown-item delete" href="/brands/<?php echo e($brand->id); ?>"><i class="fas fa-trash"></i> Sil</a>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                    <th>Logo</th>
                    <th>Marka</th>
                    <th>İşlemler</th>
                </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>