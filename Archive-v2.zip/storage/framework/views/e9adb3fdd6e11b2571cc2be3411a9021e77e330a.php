<?php $__env->startSection('content'); ?>
    <script type="text/javascript" src="<?php echo e('lib/DataTables/datatables.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo e('js/data-table.js'); ?>"></script>
    <div class="card">
        <div class="card-header">
            Ürün Yönetimi
        </div>
        <div class="card-body">
            <a href="/products/create" class="btn btn-primary"><i class="fas fa-plus"></i> Yeni Ekle</a>
            <hr>
            <table  class="data-table">
                <thead>
                <tr>
                    <th>Fotoğraf</th>
                    <th>Ürün Adı</th>
                    <th>Marka</th>
                    <th>Kategori</th>
                    <th>Alt Kategori</th>
                    <th>Ağırlık</th>
                    <th>Barkod</th>
                    <th>Kutu/Koli Barkodu</th>
                    <th>İşlemler</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img src="<?php echo e(env('AWS_URL')); ?>/<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>" width="100" class="img-thumbnail">
                        </td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->brand->name); ?></td>
                        <td><?php echo e($item->category->name); ?></td>
                        <td><?php echo e($item->subCategory->name); ?></td>
                        <td><?php echo e($item->mass); ?> <?php echo e($item->massUnit->name); ?></td>
                        <td><?php echo e($item->barcode); ?></td>
                        <td><?php echo e($item->package_barcode); ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    İşlemler
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="/products/<?php echo e($item->id); ?>/edit">
                                        <i class="fas fa-edit"></i> Düzenle</a>
                                    <a class="dropdown-item delete" href="/products/<?php echo e($item->id); ?>">
                                        <i class="fas fa-trash"></i> Sil</a>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                    <th>Fotoğraf</th>
                    <th>Ürün Adı</th>
                    <th>Marka</th>
                    <th>Kategori</th>
                    <th>Ağırlık</th>
                    <th>Barkod</th>
                    <th>İşlemler</th>
                </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>