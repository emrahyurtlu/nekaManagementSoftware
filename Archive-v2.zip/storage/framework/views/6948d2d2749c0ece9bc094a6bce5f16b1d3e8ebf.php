<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Güncelle
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <form class="needs-validation" method="post" action="/categories/<?php echo e($category->id); ?>" novalidate>
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PUT')); ?>

                <div class="form-group">
                    <label for="parent_id">Üst Kategori</label>
                    <select class="form-control select2" name="parent_id" id="parent_id" required>
                        <option value="0">Lütfen seçim yapınız</option>
                        <?php $__currentLoopData = $rootCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $category->parent_id ? 'selected' : ''); ?>>
                                <?php echo e($item->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="name">Kategori Adı</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Örn: Süt Ürünleri" required
                           value="<?php echo e($category->name); ?>"/>
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="image">İkon Yükle</label>
                    <div class="mb-2">
                        <img src="<?php echo e(env('AWS_URL')); ?>/<?php echo e($category->image); ?>" alt="<?php echo e($category->name); ?>" width="100" class="img-thumbnail">
                    </div>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="image" name="image">
                        <label class="custom-file-label" for="image">Dosya seçiniz</label>
                        <div class="invalid-feedback">
                            Bu alan boş bırakılamaz.
                        </div>
                    </div>

                </div>

                <button type="submit" class="btn btn-primary">Kaydet</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>