<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Yeni Ekle
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e($error); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <form class="needs-validation" method="post" action="/products" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Ürün Adı</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Örn: Çaykur" required />
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="barcode">Ürün Barkodu</label>
                    <input type="text" class="form-control" id="barcode" name="barcode" placeholder="Lütfen barkod giriniz" required />
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="package_barcode">Kutu/Koli Barkodu</label>
                    <input type="text" class="form-control" id="package_barcode" name="package_barcode" placeholder="Lütfen barkod giriniz" />
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="brand_id">Marka Seçiniz</label>
                    <select class="form-control select2" name="brand_id" id="brand_id" required>
                        <option>Lütfen seçim yapınız</option>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($brand->id); ?>">
                                <?php echo e($brand->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="category_id">Kategori Seçiniz</label>
                    <select class="form-control select2" name="category_id" id="category_id" required>
                        <option value="-1">Lütfen seçim yapınız</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>">
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="sub_category_id">Alt Kategori Seçiniz</label>
                    <select class="form-control select2" name="sub_category_id" id="sub_category_id" required>
                        <option value="-1">Lütfen seçim yapınız</option>
                    </select>
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="mass">Ürün Ağırlığı</label>
                    <input type="number" class="form-control" id="mass" name="mass" placeholder="Örn: 1000" required />
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="mass_unit_id">Ağırlık Birimi Seçiniz</label>
                    <select class="form-control select2" name="mass_unit_id" id="mass_unit_id" required>
                        <option>Lütfen seçim yapınız</option>
                        <?php $__currentLoopData = $massUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $massUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($massUnit->id); ?>">
                                <?php echo e($massUnit->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="invalid-feedback">
                        Bu alan boş bırakılamaz.
                    </div>
                </div>

                <div class="form-group">
                    <label for="image">Fotoğraf Yükle</label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="image" name="image">
                        <label class="custom-file-label" for="image">Dosya seçiniz</label>
                        <div class="invalid-feedback">
                            Bu alan boş bırakılamaz.
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Kaydet</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>